export const SIZES = {
  xs:8,
  sm:16,
  md:18,
  lg:32,
  xl:40,
  xxl:80,
}

export const COLORS = {
  white: '#FFF',
  black: '#000',
  primary: '#EAEFD3',
  secondary: '#27233A',
  accent:"#DCC48E",
};
