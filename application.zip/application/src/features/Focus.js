import { View, Text, StyleSheet } from 'react-native';
import { TextInput } from 'react-native-paper';
import { RoundedButton } from '../components/RoundedButton';
import { COLORS, SIZES } from '../utils/CONSTANTS';

export const Focus = () => {
  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput style={styles.textInput} mode="outlined" label="What would you like to focus on?" />
        <RoundedButton onPress={() => {console.log("btn clocekd")}} title="+" size={50} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: SIZES.xs,
  },
  inputContainer: {
    paddingHorizontal: SIZES.sm,
    justifyContent: 'center',
    alignItems:"center",
    flexDirection:"row",
    gap:SIZES.sm,
  },
  textInput:{
    flex:1
  }
});
