import {
  SafeAreaView,
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';
import { COLORS,SIZES } from './src/utils/CONSTANTS';
import { Focus } from './src/features/Focus';
// import Constants from 'expo-constants';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Focus />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
    paddingRight:SIZES.lg,
    backgroundColor: COLORS.primary,
  },
});
